# TankGame
Tank Game Assesment

DESCRIPTION
The application allows the user to control both tanks in forward and backwards positions and allowing the top of the turret to rotate on its own. The tank also allows shooting based of the turrets current position when fired and both bullets and and tank have collision boxes around them to interacte with other collision boxes is the world such as walls.

INSTALLATION
visual studios 2019 is required to load files
windows 10

USAGE
To run program open up Release folder and click into Release -> netcoreapp3.0 -> TankGame (4th from bottom)
once loaded the game will start right away. To view controlls within game hold 'P' which also pauses the game while held down.

Controls:
Both players:
H - display debug hitboxes
P - hold to pause game see game objective and view controls within game

Player 1:
W - move forward
S - move backwards
A - rotate tank left
D - rotate tank right
Q - rotate turret left
E - rotate turret right
Space Bar - Shoot

Player 2:
Num8 - move forward
Num5 - move backwards
Num4 - rotate tank left
Num6 - rotate tank right
Num7 - rotate turret left
Num9 - rotate turret right
Num0 - Shoot

SUPPORT
Contact Justin Katic at justinkatic4@gmail.com
